<h2 class="text-center mb-5">زلزال</h2>
<p class="text-center mb-3">زلزال هو موقع بسيط يساعد على تحديد وتنظيم بيانات تتعلق بالاماكن والمناطق المنكوبة
    والفرق
    العاملة على ايصال المساعدات لها في سوريا</p>
<?php /**PATH C:\wamp64\www\work\my work\zlzal\resources\views/components/navbar.blade.php ENDPATH**/ ?>