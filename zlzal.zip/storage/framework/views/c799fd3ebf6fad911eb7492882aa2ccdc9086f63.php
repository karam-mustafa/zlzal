<?php if (isset($component)) { $__componentOriginalc73518e4e557af3c08494b658146df84390e8f3a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\App::class, []); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <style>
            body {
                direction: rtl;
                background-color: #e5e5e5;
            }

            form {
                width: 600px;
                height: max-content;
                background-color: white;
            }

            .form {
                margin: 280px 0;
            }

            label {
                font-size: 15px;
            }
        </style>
     <?php $__env->endSlot(); ?>
    <div class="d-flex justify-content-center align-items-center form" style="height: 100vh; width: 100%">

        <form class="p-5" action="<?php echo e(route('cases.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
            <h5 class="text-center"><a href="/map">لرؤية الخريطة من هنا</a> </h5>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="container">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="form-group my-4">
                    <label for="case">حدد نوع الحالة <span style="color: red">* </span></label>
                    <select name="type" class="form-control" id="cases" required>
                        <option value="1" selected>انقاض، اشخاص عالقين تحت الانقاض.</option>
                        <option value="2">مراكز يتوفر فيها حاجات اساسية مثل الطعام والشراب</option>
                        <option value="3">مراكز يتوفر فيها ملابس وتدفئة</option>
                        <option value="4">فريق استجابة، فرق تطوعية</option>
                        <option value="5">مراكز ايواء</option>
                        <option value="6">مراكز يتوفر فيها مواصلات</option>
                        <option value="7">مراكز أمنة</option>
                        <option value="8">مراكز غسيل كلية</option>
                        <option value="9">مراكز ونقاط طبية</option>
                        <option value="10">تقديم المساعدة والتطوع</option>
                        <option value="11">أخرى</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="name">الاسم الثلاثي متطوع او طبيب او مهندس\اسم الجهة\اسم الفريق\اسم المركز <span
                            style="color: red">* </span></label>
                    <input type="text" required class="form-control" value="<?php echo e(old('name')); ?>" name="name"
                        id="name">
                </div>
                <div class="form-group">
                    <label for="name">رقم للتواصل\ اي وسيلة تواصل مساعدة <span style="color: red">* </span></label>
                    <input type="text" required class="form-control" value="<?php echo e(old('phone')); ?>" name="phone"
                        id="name">
                </div>

                <div class="form-group">
                    <label for="case-description">وصف الحالة\وصف البناء\ وصف امكانيات الفريق او نطاق عمله\ وصف طاقة
                        المراكز الطبية </label>
                    <textarea class="form-control" name="description" id="case-description" rows="3"><?php echo e(old('description')); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="case">حالة النقاط الطبية (خاص لنوع الحالة نقطة طبية)</label>
                    <select name="medical_point_status" class="form-control" id="cases">
                        <option value="1" selected>فعالة</option>
                        <option value="2">جزئي</option>
                        <option value="0">غير فعالة</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="city"> المدينة<span style="color: red">* </span></label>
                    <input type="text" name="city" required value="<?php echo e(old('city')); ?>" class="form-control"
                        id="city">
                </div>

                <div class="form-group">
                    <label for="area"> المنطقة<span style="color: red">* </span></label>
                    <input type="text" name="area" required value="<?php echo e(old('area')); ?>" class="form-control"
                        id="area">
                </div>

                <div class="form-group">
                    <label for="street"> الشارع <span style="color: red">* </span></label>
                    <input type="text" name="street" required value="<?php echo e(old('street')); ?>" class="form-control"
                        id="street">
                </div>

                <div class="form-group">
                    <label for="additional-data">أي بيانات اضافية</label>
                    <textarea class="form-control" name="more_info" id="additional-data" rows="3"><?php echo e(old('more_info')); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">ارسال</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc73518e4e557af3c08494b658146df84390e8f3a)): ?>
<?php $component = $__componentOriginalc73518e4e557af3c08494b658146df84390e8f3a; ?>
<?php unset($__componentOriginalc73518e4e557af3c08494b658146df84390e8f3a); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\work\my work\zlzal\resources\views/index.blade.php ENDPATH**/ ?>